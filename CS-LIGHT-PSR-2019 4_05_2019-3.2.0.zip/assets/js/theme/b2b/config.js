// this is a config template. Create a config.js in b2b directory with this content
export default {
    // print save repeat
    storeHash: "85f8f",
    apiRootUrl: "https://oiwifueo7h.execute-api.us-west-2.amazonaws.com/prod"
}
