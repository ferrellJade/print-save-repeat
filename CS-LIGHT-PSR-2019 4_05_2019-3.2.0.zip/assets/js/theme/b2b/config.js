// this is a config template. Create a config.js in b2b directory with this content
export default {
    // Dev
    // storeHash: "h3jnjw30qw",
    // apiRootUrl: "https://fl4mq0bm40.execute-api.us-west-2.amazonaws.com/prod"

    //Prod BundleB2B Demo Store
    // storeHash: "j9bye8pq04",
    // apiRootUrl: "https://8l6t4dsd6e.execute-api.us-west-2.amazonaws.com/prod"

    //store: Test Sandbox main
    // storeHash: "ye5pmu6ccg",
    // apiRootUrl: "https://l4m45kvzfh.execute-api.us-west-2.amazonaws.com/prod"

    //store: Silk Demo Store
    // storeHash: "l71mslbz8q",
    // apiRootUrl: "https://8l6t4dsd6e.execute-api.us-west-2.amazonaws.com/prod"

    // staging
    // storeHash: "wao5z0rn37",
    // apiRootUrl: "https://dk0xoldgn8.execute-api.us-west-2.amazonaws.com/prod"

    // Demo Store 2：
    // storeHash: "d3s2jyb7mz",
    // apiRootUrl: "https://l4m45kvzfh.execute-api.us-west-2.amazonaws.com/prod"

    // Demo Store 3：
    // storeHash: "f2osxjjnxj",
    // apiRootUrl: "https://l4m45kvzfh.execute-api.us-west-2.amazonaws.com/prod"

    // Demo Store 4：
    // storeHash: "ikaftqo2vu",
    // apiRootUrl: "https://l4m45kvzfh.execute-api.us-west-2.amazonaws.com/prod"

    // Demo Store 5：
    // storeHash: "nmwa33vmek",
    // apiRootUrl: "https://l4m45kvzfh.execute-api.us-west-2.amazonaws.com/prod"

    // Demo Store 6：
    // storeHash: "rtmh8fqr05",
    // apiRootUrl: "https://l4m45kvzfh.execute-api.us-west-2.amazonaws.com/prod"

    // print save repeat
    storeHash: "85f8f",
    apiRootUrl: "https://oiwifueo7h.execute-api.us-west-2.amazonaws.com/prod"
}
