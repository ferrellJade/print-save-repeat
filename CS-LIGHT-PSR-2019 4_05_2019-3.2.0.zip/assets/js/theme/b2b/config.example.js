//this is a config template. Create a config.js in b2b directory with this content.
export default {
  storeHash: "[enter store hash here]",
  apiRootUrl: "[enter API root URL here]"
}
